//
// Created by sescer on 17.12.22.
//

#ifndef CALCULATOR_LINE_SCHEDULER_HPP
#define CALCULATOR_LINE_SCHEDULER_HPP
#include <string>
#include <fstream>
#include <filesystem>
#include <atomic>
#include <queue>
#include <thread>

#include "sheduler.hpp"

class LinearScheduler final: public Scheduler{
    double sum{0.};
    bool need_log{true};

public:
    explicit LinearScheduler(bool needLog) : need_log(needLog) {}

    void process_file(std::filesystem::path file) override{
        std::ifstream is{file};
        std::string str;
        getline(is, str);

        Parser p{str};
        Command cmd = p.get();

        if(need_log){
            Logger::get_instance().log(cmd.get_info());
        }
        sum += cmd.execute();
    }

    double get_sum() override{
        return sum;
    }
};
#endif //CALCULATOR_LINE_SCHEDULER_HPP
