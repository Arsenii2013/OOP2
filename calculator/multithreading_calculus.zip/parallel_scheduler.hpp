//
// Created by sescer on 17.12.22.
//

#ifndef CALCULATOR_PARALLEL_SCHEDULER_HPP
#define CALCULATOR_PARALLEL_SCHEDULER_HPP
#include <string>
#include <fstream>
#include <filesystem>
#include <atomic>
#include <queue>
#include <thread>

#include "sheduler.hpp"

class ParallelScheduler final: public Scheduler{
private:
    bool need_log{true};
    std::size_t n_threads{0U};


    bool stop{false};
    std::atomic<double> sum{0.};

    std::mutex q_mutex;
    std::queue<std::filesystem::path> fnames;
    std::condition_variable new_name;

    std::vector<std::jthread> worker_threads{};

    void pop_and_work(){
        while (true) {
            std::filesystem::path fname;
            {
                std::unique_lock lock(q_mutex);
                new_name.wait(lock, [this] { return !fnames.empty(); });
                fname = fnames.front();
                if(fname.empty()){
                    break;
                }
                fnames.pop();
            }

            std::ifstream is(fname);
            std::string str;
            getline(is, str);
            Parser p{str};
            Command cmd = p.get();
            if(need_log){
                Logger::get_instance().log(cmd.get_info());
            }
            sum += cmd.execute();
        }
    }

    void send_stop(){
        std::lock_guard lock(q_mutex);
        fnames.push({});
        new_name.notify_all();
    }
public:

    ParallelScheduler(bool needLog, std::size_t nThreads) : need_log(needLog), n_threads(nThreads) {
        if(n_threads > 7){
            throw std::runtime_error("too many threads");
        }
        for(std::size_t i = 0U; i < n_threads; i++) {
            worker_threads.emplace_back([this] { pop_and_work(); });
        }
    }

    void process_file(std::filesystem::path file) override{
        if(file.empty()){
            throw std::runtime_error("invalid path");
        }

        std::lock_guard lock(q_mutex);
        fnames.push(file);
        new_name.notify_one();
    }

    double get_sum() override{
        send_stop();
        pop_and_work();

        for(auto &thread : worker_threads){
            thread.join();
        }

        return sum;
    }
    ~ParallelScheduler() override{
        send_stop();
    }
};

#endif //CALCULATOR_PARALLEL_SCHEDULER_HPP
