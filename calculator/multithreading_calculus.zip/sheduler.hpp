//
// Created by sescer on 09.12.22.
//

#ifndef CALCULATOR_SHEDULER_HPP
#define CALCULATOR_SHEDULER_HPP

#include <string>
#include <fstream>
#include <filesystem>
#include <atomic>
#include <queue>
#include <thread>

#include "parser.hpp"

class Scheduler{

public:
    virtual void process_file(std::filesystem::path file) = 0;
    virtual double get_sum() = 0;
    virtual ~Scheduler() = default;
};

#endif //CALCULATOR_SHEDULER_HPP
