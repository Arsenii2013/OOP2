//
// Created by sescer on 09.12.22.
//

#ifndef COMMAND_COMMANDDTO_HPP
#define COMMAND_COMMANDDTO_HPP
#include <iostream>
#include <memory>
#include <utility>

class CommandDTO final{
    std::string name;
    std::size_t pos{};
    std::size_t start{};
    std::size_t stop{};
    std::string str;
public:
    CommandDTO() = default;

    explicit CommandDTO(std::string name) : name(std::move(name)) {}

    CommandDTO(std::string name, const size_t pos) : name(std::move(name)), pos(pos) {}

    CommandDTO(std::string name, const size_t start, const size_t stop) : name(std::move(name)), start(start), stop(stop) {}

    CommandDTO(std::string name, const size_t pos, std::string str) : name(std::move(name)), pos(pos), str(std::move(str)) {}

    [[nodiscard]] const std::string &get_name() const {
        return name;
    }

    [[nodiscard]] size_t get_start() const {
        return start;
    }

    [[nodiscard]] size_t get_stop() const {
        return stop;
    }

    [[nodiscard]] std::size_t get_pos() const {
        return pos;
    }

    [[nodiscard]] const std::string &get_str() const {
        return str;
    }
};

#endif //COMMAND_COMMANDDTO_HPP
